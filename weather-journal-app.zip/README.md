# Landing Page Project procedural & oop

## Table of Contents

* [Description](#Description)
* [Technologies-used](#Technologies-used)
* [packages-used](#packages-used)
* [API-used](#API-used)

## Description

this project is using `JavaScript` , `Node.js` to create a dynamic weather journal app that retrives temperature using zip code .


## Technologies used

Technologies used on this app is  `JavaScript` , `CSS`, `HTML` .

## packages used

node packages used in this app is `express` , `body-parser` , `cors` .

## API used

API used in this app is `openweathermap.org` API.